module Jdbc_Musicplayer {
	requires java.sql;
}